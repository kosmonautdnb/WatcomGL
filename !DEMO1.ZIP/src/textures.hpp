#ifndef __TEXTURES_HPP__
#define __TEXTURES_HPP__

extern unsigned int glowTexture;
extern unsigned int glowTexture2;
extern unsigned int cloudTexture;
extern unsigned int shotTexture[6];
extern unsigned int explosionTexture;
extern unsigned int smokeTexture;

void loadTextures();

#endif // __TEXTURES_HPP__
