#ifndef __BACKGRND_HPP__
#define __BACKGRND_HPP__

extern double levelScrollY;
extern double levelScrollX;

void clearFrame();
void paintLevel1();

#endif //__BACKGRND_HPP__
